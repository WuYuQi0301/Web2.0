$(function(){
	$('#logout').click(function() {
		window.location.href='/logout';
	})
})