# "Sign in" homework
## Dependency
1. Go to the root direcory of the program
2. Type the command

        npm install
## Usage
1. Run mongodb
2. Go to the root direcory of the program
3. Type the command

        npm start
4. Start enjoying the program in your browser with url
   <http:localhost:8000>
> <b>Hint : </b>The program state will be shown in your terminal 
