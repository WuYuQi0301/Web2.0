class stack:
    def __init__(self):
        self.list = []
    def push(self,item):
        self.list.append(item)
    def pop(self):
        self.list.pop()
    def empty(self):
        return len(self.list) == 0

if __name__ == '__main__':
    a = stack()
    print a.list
    a.push(222)
    a.push(44)
    print a.list
    print a.empty()
    a.pop()
    print a.list
    a.pop()
    print a.list
    print a.empty()
