import sys

for i in range(0,11):
    print i



if __name__ == '__main__':
    f = open(sys.argv[0],'r')
    print(f.read())
