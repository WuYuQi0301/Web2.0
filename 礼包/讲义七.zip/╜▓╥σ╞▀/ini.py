#!/usr/local/bin/python
#-*- coding: UTF-8 -*-

"""
ini配置文件中类似key-value的配置内容
[ipdata]
ip1 = ""
ip2 = ""
"""

import ConfigParser

IP1 = ""
IP2 = ""
INITXT = "IP.ini" #INI文件名字

#读取INI
def ini_get():
    try:
        global IP1
        global IP2
        global INITXT
        config = ConfigParser.ConfigParser()
        config.readfp(open(INITXT))
        IP1 = config.get("ipdata","ip1")
        IP2 = config.get("ipdata","ip2")
    except:
        print "wrong"
        ini_add("","") #读取错误则写入ini

#写入INI
def ini_add(ip1,ip2):
    try:
        global INITXT
        config = ConfigParser.Configparser()
        config.add_section('ipdata') #设置section段以及对应的值
        config.set("ipdata","ip1",ip1)
        config.set("ipdata","ip2",ip2)
        config.write(open(INITXT,"w")) #重新写入文件
    except:
        print "wrong"

#修改INI
def ini_write(ip1,ip2):
    try:
        global INITXT
        config = ConfigParser.ConfigParser()
        config.read(INITXT)
        if not config.has_section("ipdata"): #检测是否存在section，不存在则创建
            temp = config.add_section("ipdata")
        config.set("ipdata","ip1",ip1)
        config.set("ipdata","ip2",ip2)
        config.write(open(INITXT,"w")) #重新写入文件
    except:
        print "wrong"

if __name__ == '__main__':
    ini_get()
    print IP1
    print IP2
    ini_write('111','222')
    print IP1
    print IP2


        
