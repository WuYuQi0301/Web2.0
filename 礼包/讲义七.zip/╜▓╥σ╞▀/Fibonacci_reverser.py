a,b,result = 0,1,[]
for i in range(1,11):
    result.append(a)
    a,b = b,a+b
result.reverse()

if __name__ == '__main__':
    for i in range(0,10):
        print result[i]


